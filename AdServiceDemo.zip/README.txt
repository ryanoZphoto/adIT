﻿Ad Service Executable
====================

This executable contains everything needed to run the Ad Service.

To start:
1. Double-click AdService.exe
2. Enter your OpenAI API key when prompted
3. The service will automatically:
   - Create a working directory (ad_service_data) next to the executable
   - Set up all required files and configurations
   - Start all necessary services
   - Open your browser to:
     * Chat Interface (http://localhost:8501)
     * Ad Manager (http://localhost:8502)
     * Metrics Dashboard (http://localhost:8503)

IMPORTANT: The first run may take longer as it sets up all necessary components.

No installation or Python knowledge required!
